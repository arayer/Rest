# 🚀 Python Environment Setup Guide
**Purpose:** Set up uv Python environment and Jupyter Lab

---

## 📚 What This Guide Covers

This guide will help you:
- Install `uv` (fast Python package manager)
- Create a virtual environment for this project
- Install all required packages
- Set up Jupyter Lab for running notebooks
- Run the Streamlit app

---

## 1️⃣ Installing uv

### Option A: macOS/Linux (Recommended)

Open Terminal and run:

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

After installation, restart your terminal or run:

```bash
source $HOME/.cargo/env
```

### Option B: macOS with Homebrew

```bash
brew install uv
```

### Option C: Windows

Open PowerShell and run:

```powershell
powershell -c "irm https://astral.sh/uv/install.ps1 | iex"
```

### ✅ Verify Installation

Check that uv is installed:

```bash
uv --version
```

You should see output like: `uv 0.x.x`

---

## 2️⃣ Setting Up This Project

### Step 1: Navigate to Project Folder

```bash
cd /path/to/ITOM_HW2-london
```

**Example:**
```bash
cd ~/Dropbox/Data/SMU_teaching/ITOM_HW2-london
```

### Step 2: Create Virtual Environment

```bash
uv venv
```

This creates a `.venv` folder in your project directory.

### Step 3: Activate the Environment

**macOS/Linux:**
```bash
source .venv/bin/activate
```

**Windows (PowerShell):**
```powershell
.venv\Scripts\activate
```

**Windows (Command Prompt):**
```cmd
.venv\Scripts\activate.bat
```

✅ **You'll know it's activated** when you see `(.venv)` at the start of your terminal prompt.

### ✅ Verify Environment Activation

After activating, verify you're using the correct Python:

**macOS/Linux:**
```bash
which python
```

**Windows:**
```powershell
Get-Command python
# OR
where python
```

**Expected output (macOS/Linux):**
```
/Users/YOUR_USERNAME/Dropbox/Data/SMU_teaching/ITOM_HW2-london/.venv/bin/python
```

**Expected output (Windows):**
```
C:\Users\YOUR_USERNAME\...\ITOM_HW2-london\.venv\Scripts\python.exe
```

If you see a **system Python path** (like `/usr/bin/python` or `C:\Python39\python.exe`), the environment is **NOT activated**. Try activating again.

### Step 4: Install Project Dependencies

```bash
uv pip install -r requirements.txt
```

This installs: Streamlit, Pandas, Plotly, and other required packages.

---

## 3️⃣ Installing Jupyter Lab

### Step 1: Install Jupyter Lab and ipykernel

Make sure your environment is activated, then run:

```bash
uv pip install jupyterlab ipykernel
```

### Step 2: Register This Environment as a Jupyter Kernel

```bash
python -m ipykernel install --user --name=itom6265 --display-name "Python (UV)"
```

This creates a kernel named "Python (UV)" that will appear in Jupyter Lab.

### Step 3: Launch Jupyter Lab 

```bash
jupyter lab
```

- Jupyter Lab will open in your default browser
- URL will be: `http://localhost:8888`
- The terminal will show a token for first-time access

### Step 4: Verify Kernel is Available

In Jupyter Lab:
1. Click "New Launcher" (+ icon)
2. You should see "Python (itom6265)" as a notebook option
3. Create a new notebook and test:

```python
import pandas as pd
import sqlite3
print("Environment ready!")
```

---

## 4️⃣ Running the Streamlit App

Make sure your environment is activated:

```bash
streamlit run app_pandas.py
```

- App will open in your browser automatically
- URL: `http://localhost:8501`
- To stop: Press `Ctrl + C` in terminal

---

## 5️⃣ Daily Workflow

### Starting Your Work Session

1. **Navigate to project folder:**
   ```bash
   cd ~/Dropbox/Data/SMU_teaching/ITOM_HW2-london
   ```

2. **Activate environment:**
   ```bash
   source .venv/bin/activate  # macOS/Linux
   # OR
   .venv\Scripts\activate     # Windows
   ```

3. **Choose what to run:**
   ```bash
   # Option A: Run Streamlit app
   streamlit run app.py

   # Option B: Launch Jupyter Lab
   jupyter lab
   ```

4. **When done, deactivate:**
   ```bash
   deactivate
   ```

---

## 6️⃣ Managing Packages

### Installing Additional Packages

```bash
# Install a single package
uv pip install package-name

# Install multiple packages
uv pip install package1 package2 package3

# Install specific version
uv pip install pandas==2.1.1
```

### Listing Installed Packages

```bash
uv pip list
```

### Updating a Package

```bash
uv pip install --upgrade package-name
```

### Removing a Package

```bash
uv pip uninstall package-name
```

---

## 7️⃣ Quick Reference

| Task | Command |
|------|---------|
| **Install uv** | `curl -LsSf https://astral.sh/uv/install.sh \| sh` (macOS/Linux) |
| **Create environment** | `uv venv` |
| **Activate (macOS/Linux)** | `source .venv/bin/activate` |
| **Activate (Windows)** | `.venv\Scripts\activate` |
| **Install requirements** | `uv pip install -r requirements.txt` |
| **Install package** | `uv pip install package-name` |
| **Launch Jupyter Lab** | `jupyter lab` |
| **Run Streamlit app** | `streamlit run tech_product_app.py` |
| **Deactivate environment** | `deactivate` |
| **List packages** | `uv pip list` |

---
